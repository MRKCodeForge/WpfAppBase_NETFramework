﻿using System.Windows;

namespace $safeprojectname$.Views
{
	/// <summary>
	/// Interaction logic for SecondaryWindow.xaml
	/// </summary>
	public partial class SecondaryWindow : Window
	{
		public SecondaryWindow()
		{
			InitializeComponent();
		}
	}
}
